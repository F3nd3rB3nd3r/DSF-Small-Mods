-- HOW TO INSTALL --

1. Navigate to your Driver: San Francisco installation folder (with Driver.exe).
2. Make backups of "ScriptsActionActivities", "ScriptsChallenges", "ScriptsChapter" 1 to 7 .fchunk files located inside "media" folder at the install directory.
3. Extract contents of the Felony Rework.zip to the install directory. Click "Yes" to replace all when asked.

Mod is now using DriverNG hook and compatible with WhiteSnoop's Mod Menu; though make sure Felony Rework is installed last to ensure it works.

If you have an old install of Felony Rework or my older mods, 
make sure to revert to an unmodded ScriptLuaScripts.fchunk and delete preload.lua provided by older versions!!!

If you install any of my other mods (Moods Rework, No Abilities etc.), do not use a modded ScriptLuaScripts.fchunk file they may provide at the current time.

-- HOW TO UNINSTALL -- 

Move in your backups and cross-reference with the provided .zip to see which files it adds without replacing. 
You won't need them and are free to delete at will.

-- CREDITS --

Huge thanks to Mark (Fireboyd78) for making this all possible with his tools and constant, reliable assistance with programming and otherwise.
Soapy for DNG Hook & general help.
WhiteSnoop & FenderBender for Lua help, testing and feedback.
Klancnik for allowing me to use his garage mod & integrate it. 
Iain McNally for his constant advise and testing.
Also Custo, VortexLeBelge, Helomyname for testing & suggestions. 