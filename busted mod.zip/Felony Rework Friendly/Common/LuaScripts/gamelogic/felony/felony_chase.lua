module("felony_chase", package.seeall)
local copCars = {
  [267] = true,
  [271] = true,
  [280] = true,
  [269] = true,
  [265] = true,
  [302] = true
}
local effectActive = false
local bustedTime = 5
local startTime = nil
local bustedRadius = 25
local maximumBustedSpeed = 5
local promptActive = false
local oneSecRate = 100 / bustedTime
function getawayBustedCounter()
    local getawayGameVehicle = localPlayer.primaryFelony.getawayGameVehicle
    if copCars[localPlayer.currentVehicle.gameVehicle.model_id] and
    getawayGameVehicle.speed < maximumBustedSpeed and
    distanceCalculation(getawayGameVehicle,bustedRadius) and not effectActive then
        effectActive = true
        startTime = g_NetworkTime
    end
    if effectActive and startTime then
        if not promptActive then
			feedbackSystem.menusMaster.masterSetVariable("iScore_Feedback_Gauge_State", 1)
			feedbackSystem.menusMaster.masterSetTextVariable("score_feedback_gauge", "BUSTED")
             promptActive = true
        end
		feedbackSystem.menusMaster.masterSetVariable("iScore_Feedback_Gauge", (startTime + bustedTime - g_NetworkTime) * oneSecRate)
    end
    if effectActive and startTime and g_NetworkTime > startTime + bustedTime then
        bustedCounterCleanUp()
    end
    if not distanceCalculation(getawayGameVehicle,bustedRadius) or getawayGameVehicle.speed > maximumBustedSpeed or not copCars[localPlayer.currentVehicle.gameVehicle.model_id] then
        effectActive = false
        if promptActive then
			feedbackSystem.menusMaster.masterSetVariable("iScore_Feedback_Gauge_State", 2)
            promptActive = false
        end
    end
    if getawayGameVehicle.damage > 0.995 or not Chase.IsAChaseActive() or not localPlayer.currentVehicle then
        bustedCounterCleanUp()
    end
end

function distanceCalculation(getawayGameVehicle,bustedRadius)
	if not Chase.GetZapReturnChaser() then
		return vec.vector():sub(localPlayer.currentVehicle.position, getawayGameVehicle.position):length() < bustedRadius
	else
		return vec.vector():sub(localPlayer.currentVehicle.position, getawayGameVehicle.position):length() < bustedRadius or vec.vector():sub(Chase.GetZapReturnChaser().position, getawayGameVehicle.position):length() < bustedRadius
	end
end

function bustedCounterCleanUp()
    local getawayGameVehicle = localPlayer.primaryFelony.getawayGameVehicle
    feedbackSystem.menusMaster.masterSetVariable("iScore_Feedback_Gauge_State", 0)
    felony_chase.wrecked(getawayGameVehicle)
    getawayGameVehicle.damage = 1
    Chase.StopAll()
    effectActive = false
    startTime = nil
    removeUserUpdateFunction("getawayBustedCounter")
end

local promptTable = {
  counter = true,
  priority = 1,
  felony = true
}
local iCamParams = {
  duration = 3,
  speed = 0.5,
  framing = "wide",
  angleyaw = "rear",
  hudParams = {prompts = true, willpowerRewards = true}
}
local disablePromptClear = false 
goalCallbacks = {}
function registerGoalCallback(callback, type)
  goalCallbacks[type] = goalCallbacks[type] or {}
  goalCallbacks[type][#goalCallbacks[type] + 1] = callback
end
function unregisterGoalCallback(callback, type)
  if goalCallbacks[type] then
    local remove = false
    for i, storedCallback in ipairs(goalCallbacks[type]) do
      if storedCallback == callback then
        remove = i
        break
      end
    end
    if remove then
      table.remove(goalCallbacks[type], remove)
    end
  end
end
local unregisterAllGoalCallbacks = function()
  goalCallbacks = {}
end
local CopTimeTriggerCount = 0
function chaseOngoingAudioFeedback()
  return function()
    CopTimeTriggerCount = CopTimeTriggerCount + 1
    if CopTimeTriggerCount == 20 then
      if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
        Commentary.TriggerEvent("CopTime", nil, nil, 0, true)
      end
      CopTimeTriggerCount = 0
    end
  end
end
FelPursuingFirst = false
FelPursuing = false
FelHighSpeedFirst = false
FelHighSpeed = false
FelSlowedGetawayFirst = false
FelSlowedGetaway = false
FelWeakRam = false
FelMediumRam = false
FelStrongRam = false
pursuingCooldown = 0
highSpeedCooldown = 0
getawaySlowedTimer = 0
getawaySlowedCooldown = 0
function getawayCrimeCheckList()
  -- local angleComparison
  -- local angle = params.angle or 0.1
  if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) and not localPlayer.inCutsceneOrIcam then
    if GameVehicleResource.withinRadius(localPlayer.currentVehicle.position, localPlayer.primaryFelony.getawayGameVehicle.position, 170) then
	  if FelPursuingFirst == false then
	    FelPursuing = true
	    FelPursuingFirst = true
	    pursuingCooldown = g_NetworkTime
	  elseif g_NetworkTime - pursuingCooldown < 60 then
	    FelPursuing = false
	  else
	    FelPursuing = true
	    pursuingCooldown = g_NetworkTime
      end
	end
    if GameVehicleResource.withinRadius(localPlayer.currentVehicle.position, localPlayer.primaryFelony.getawayGameVehicle.position, 50)	and localPlayer.primaryFelony.getawayGameVehicle.speed >= 42 and localPlayer.currentVehicle.gameVehicle.speed >= 49.5 then -- 49.5
	  if FelHighSpeedFirst == false then
	    FelHighSpeed = true
	    FelHighSpeedFirst = true
	    highSpeedCooldown = g_NetworkTime
	  elseif g_NetworkTime - highSpeedCooldown < 60 then
	    FelHighSpeed = false
	  else
	    FelHighSpeed = true
	    highSpeedCooldown = g_NetworkTime
      end
    end
  end
  if FelSlowedGetawayValid == true and not localPlayer.inCutsceneOrIcam then
    getawaySlowedTimer = g_NetworkTime
    addUserUpdateFunction("getawaySlowedCheck", getawaySlowedCheck, 120)
	FelSlowedGetawayValid = false
  end
  if FelWeakValid == true then
    FelWeakRam = true
	FelWeakValid = false
  elseif FelMediumValid == true then
    FelMediumRam = true
	FelMediumValid = false
  elseif FelStrongValid == true then
    FelStrongRam = true
	FelStrongValid = false
  end
end
searching = false
function heatTable()
  if searching == true then
    Chase.SetSettings(localPlayer.primaryFelony.getawayGameVehicle, Heat[5])
    searching = false
    print("settings changed to outsideRadius")
  elseif searching == false then
    Chase.SetSettings(localPlayer.primaryFelony.getawayGameVehicle, Heat[getawayPreference])
    print(getawayPreference)
    print("settings changed to normal")
  end
end
function getawaySlowedCheck()
  if g_NetworkTime - getawaySlowedTimer < 5 then
    if localPlayer.primaryFelony.getawayGameVehicle.speed <= evaderSpeed/4 then -- or localPlayer.primaryFelony.getawayGameVehicle.speed < 18 then
	  print(localPlayer.primaryFelony.getawayGameVehicle.speed)
	  FelSlowedGetaway = true
	  removeUserUpdateFunction("getawaySlowedCheck")
	end
  else
	removeUserUpdateFunction("getawaySlowedCheck")
  end
end
local lastCopRamTime = 0
function getawayCollsionCallback(collisionData)
  if g_NetworkTime - lastCopRamTime < 5 then
    return
  end
  if collisionData and collisionData.GameVehicle and collisionData.CollidedGameVehicle and collisionData.GameVehicle.damage < 1 and collisionData.GameVehicleResponsibleForCollision ~= collisionData.GameVehicle and localPlayer.currentVehicle and localPlayer.currentVehicle.gameVehicle == collisionData.CollidedGameVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
    Commentary.TriggerEvent("CopRam", nil, nil, 0, true)
    CopTimeTriggerCount = 0
    lastCopRamTime = g_NetworkTime
  end
end
FelWeakValid = false
FelMediumValid = false
FelStrongValid = false
FelSlowedGetawayValid = false
timeSinceLastCollision = 0
function getawayCollsionCallback2(collisionData)
  if collisionData and collisionData.GameVehicle and collisionData.CollidedGameVehicle and collisionData.GameVehicle.damage < 1 and collisionData.GameVehicle and localPlayer.currentVehicle and localPlayer.currentVehicle.gameVehicle == collisionData.CollidedGameVehicle then
    local collisionForce = collisionData.Force
	if g_NetworkTime - timeSinceLastCollision > 0.3 and collisionData.Force >= 7500 and collisionData.Force < 12500 then
      FelWeakValid = true
	  FelMediumValid = false
	  FelStrongValid = false
	elseif g_NetworkTime - timeSinceLastCollision > 0.3 and collisionData.Force >= 12500 and collisionData.Force < 22500 then
      FelMediumValid = true
	  FelWeakValid = false
	  FelStrongValid = false
	elseif g_NetworkTime - timeSinceLastCollision > 0.3 and collisionData.Force >= 22500 then
      FelStrongValid = true
	  FelWeakValid = false
	  FelMediumValid = false
	end
  end
  if g_NetworkTime - timeSinceLastCollision > 0.3 then
    FelSlowedGetawayValid = true
    evaderSpeed = localPlayer.primaryFelony.getawayGameVehicle.speed
  end
  timeSinceLastCollision = g_NetworkTime
end
local workingVector = vec.vector()
local promptDistance = 150
local losingRadius = 350
local function doRapidShiftPrompt(getawayGameVehicle)
  local numZapReturns = ProfileSettings.GetNumZapReturns()
  local playerDistance, teamMate, teamMateDistance
  local showingReturnPrompt = false
  return function()
    numZapReturns = ProfileSettings.GetNumZapReturns()
    if localPlayer.zapReturning then
      feedbackSystem.menusMaster.clearSecondaryTextPrompt()
    end
    if numZapReturns > 30 then
      removeUserUpdateFunction("doRapidShiftPrompt")
      return
    elseif localPlayer.currentVehicle then
      playerDistance = workingVector:sub(localPlayer.currentVehicle.position, getawayGameVehicle.position):length()
      if playerDistance > promptDistance and playerDistance < losingRadius then
        teamMate = Chase.GetZapReturnChaser()
        if teamMate then
          teamMateDistance = GameVehicleResource.withinRadius(teamMate.position, getawayGameVehicle.position, playerDistance)
          if teamMateDistance and not feedbackSystem.menusMaster.primaryPromptActive and not feedbackSystem.menusMaster.secondaryPromptActive and not showingReturnPrompt then
            feedbackSystem.menusMaster.secondaryTextPrompt("ID:234447", nil, false, false, true, localPlayer.buttonLayout.zapReturn, function()
              showingReturnPrompt = false
            end, {
              button = "Zap_Return",
              pressType = "JustPressed"
            })
            showingReturnPrompt = true
          end
        end
      elseif showingReturnPrompt then
        feedbackSystem.menusMaster.clearSecondaryTextPrompt()
        showingReturnPrompt = false
      end
    end
  end
end
local showStartPrompt = function()
  feedbackSystem.menusMaster.primaryTextPrompt("ID:178462")
end
function started(getawayGameVehicle)
  getawayPreference = math.random(1,4)
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then 
    feedbackSystem.menusMaster.currentHUDSetVariable("iMinimap_flash", 2)
  end
  if not localPlayer:getTaskObject() then
    if not ProfileSettings.GetFreeDriveFelonyTutorialPlayed() then
      CutsceneFiles.tutorials.playTutorial("ID:243884", nil, function()
        showStartPrompt()
        ProfileSettings.SetFreeDriveFelonyTutorialPlayed(true)
        felony_feedback.setupFelonyHUD()
        GameVehicleResource.setDisableAllDamage(getawayGameVehicle, false)
        if localPlayer.primaryFelony.chasers[1] then
          GameVehicleResource.setDisableAllDamage(localPlayer.primaryFelony.chasers[1], false)
        end
      end)
    else
      showStartPrompt()
      local function callback()
        felony_feedback.setupFelonyHUD()
        GameVehicleResource.setDisableAllDamage(getawayGameVehicle, false)
        if localPlayer.primaryFelony.chasers[1] then
          GameVehicleResource.setDisableAllDamage(localPlayer.primaryFelony.chasers[1], false)
        end
        iCamParams.callbackFunction = nil
      end
      iCamParams.callbackFunction = callback
      iCamParams.cameraTargets = {getawayGameVehicle}
      iCamActivationTableInput(iCamParams)
    end
    print("Presence set to Trying To Takedown A Getaway")
    presenceSystem.setPresence(7)
    localPlayer:clearPreviousVehicle()
    feedbackSystem.menusMaster.updateFreedriveHintText()
  end
  Commentary.TriggerEvent("CopJoin", nil, nil, 0, false)
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    FelTimeTriggerCount = 0  
    OneShotSound.Play("HUD_Fel_Gained")
  end
  CopTimeTriggerCount = 0
  lastCopRamTime = g_NetworkTime
  addUserUpdateFunction("chaseOngoing", chaseOngoingAudioFeedback(), 120)
  addUserUpdateFunction("getawayCrimeCheck", getawayCrimeCheckList, 120)
  if isAbilityUnlocked("zapReturn") then
    addUserUpdateFunction("doRapidShiftPrompt", doRapidShiftPrompt(getawayGameVehicle), 120)
  end
  if not isMissionActive() then
    checkBackup()
  end
  collision_system.RegisterCollisionCallback(getawayGameVehicle, getawayCollsionCallback)
  collision_system.RegisterCollisionCallback(getawayGameVehicle, getawayCollsionCallback2)
  addUserUpdateFunction("getawayBustedCounter",getawayBustedCounter,5)
end  
function checkBackup()
    local interceptorVehicles = {
	134,
	135,
	162,
	163,
	182,
	189,
	207,
	210,
	211,
	212,
	214,
	216,
	221,
	224,
	225,
	226,
	232,
	240,
	241,
	243,
	244,
	125,
	126,
	133,
	255,
	119,
	139,
	143,
	142,
	139,
	142,
	300,
	279,
	151,
	173,
	175,
	303,
	181,
	189,
	193,
	194,
	195,
	206,
	213,
	227,
	299,
	228,
	229,
	278,
	275
}
  local modelIDs = interceptorVehicles
    for i = 1, #modelIDs do
    local modelID = modelIDs[i]
  if localPlayer.primaryFelony.getawayGameVehicle.model_id == (modelIDs[i]) and localPlayer.primaryFelony.settings.chaseMode == "Cop" then
      if not TrafficSpooler.IsMissionVehicleLoaded(265) then
	  TrafficSpooler.SetAsPlayerVehicle(265)
      FelonyVehicleSpawnManager.AddModelType(265, 1, nil)
	  print("Interceptor unit was not in memory but is now here")
	  else
      FelonyVehicleSpawnManager.AddModelType(265, 1, nil)
	  print("Interceptor unit is here")	  
      end 
    end
  end
  local heavyVehicles = {
	246,
	167,
	201,
	152,
	290,
	284,
	298,
	291,
	285,
	286,
	301
}
  local modelIDs2 = heavyVehicles
    for i = 1, #modelIDs2 do
    local modelID2 = modelIDs2[i]
  if localPlayer.primaryFelony.getawayGameVehicle.model_id == (modelIDs2[i]) and localPlayer.primaryFelony.settings.chaseMode == "Cop" then
     if not TrafficSpooler.IsMissionVehicleLoaded(118) then
	 TrafficSpooler.SetAsPlayerVehicle(118)
     FelonyVehicleSpawnManager.AddModelType(118, 1, nil)	 
	 print("Fake SWAT were not in memory but have arrived")
	 else
     FelonyVehicleSpawnManager.AddModelType(118, 1, nil)	 
	 print("Fake SWAT have arrived")	 
     end  
    end
  end
  if not isMissionActive() then
    heatTable()
  end
end
function ended(getawayGameVehicle)
  feedbackSystem.menusMaster.currentHUDSetVariable("iMinimap_flash", 0) 
  removeUserUpdateFunction("chaseOngoing")
  removeUserUpdateFunction("doRapidShiftPrompt")
  removeUserUpdateFunction("escapeCountdown")
  removeUserUpdateFunction("warningCountdown")
  removeUserUpdateFunction("getawayCrimeCheck")
  FelPursuingFirst = false
  FelPursuing = false
  FelHighSpeedFirst = false
  FelHighSpeed = false
  FelSlowedGetawayFirst = false
  FelSlowedGetaway = false
  FelWeakRam = false
  FelMediumRam = false
  FelStrongRam = false
  FelWeakValid = false
  FelMediumValid = false
  FelStrongValid = false
  FelSlowedGetawayValid = false
  felony_patrollingVehicleManager.setSpawningModels()
  PatrollingVehicleManager.Enable(true)
  felony_patrollingVehicleManager.enablePatrollingVehiclesSpawning(true)  
  PatrollingVehicleManager.SetRequiredVehicleCount(5) 
  local agent = vehicleManager.getAgentFromGameVehicle(getawayGameVehicle)
  if agent then
    localPlayer.clearFreedriveMarkers(agent)
  end
  local waitUntilNotBusy = function(callback)
    return function()
      if not localPlayer.inCutsceneOrIcam then
        if callback then
          callback()
        end
        removeUserUpdateFunction("busyWait")
      end
    end
  end
  if not localPlayer:getTaskObject() then
    local function callback()
      activeChallenges.enableActivities()
      felony_suspiciousVehicleManager.enableSuspiciousVehicles(true)
      local agent = vehicleManager.vehiclesByGameVehicle[getawayGameVehicle]
      if agent then
        agent:setDebugRequiredVehicles(false)
      end
    end
    addUserUpdateFunction("busyWait", waitUntilNotBusy(callback), 1)
    getawayGameVehicle.softness = 1
    localPlayer:clearFelony(getawayGameVehicle)
    felony_feedback.endFelony(false)
    localPlayer.missionSupport.setFreedriveMode()
    presenceSystem.setPresence(9)
    feedbackSystem.menusMaster.updateFreedriveHintText()
    localPlayer:buildZapReturn()
  -- if not isMissionActive() then 
  -- clearCopCars()
  -- end
    FelonyVehicleSpawnManager.ClearModelTypes()
    felony_patrollingVehicleManager.setSpawningModels()
    felony_suspiciousVehicleManager.enableSuspiciousVehicles(false)
  end
  collision_system.UnRegisterCollisionCallback(getawayGameVehicle, getawayCollsionCallback)
  collision_system.UnRegisterCollisionCallback(getawayGameVehicle, getawayCollsionCallback2)
  takeOwnershipOfActivityGameVehicle()
end
-- function clearCopCars()
    -- TrafficSpooler.ReleaseMissionVehicle(265)
    -- print("unspooled interceptor from memory")
    -- TrafficSpooler.ReleaseMissionVehicle(118)
    -- print("unspooled fake SWAT from memory")
-- end
function leftChaseArea(getawayGameVehicle)
  removeUserUpdateFunction("escapeCountdown")
  removeUserUpdateFunction("warningCountdown")
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  feedbackSystem.menusMaster.primaryTextPromptParam({
    prompt = "ID:245234",
    priority = 1,
    delayTime = 3
  })
  if not localPlayer:getTaskObject() then
    felony_feedback.endFelony(false)
  end
  unregisterAllGoalCallbacks()
end
function wrecked(getawayGameVehicle)
  removeUserUpdateFunction("escapeCountdown")
  removeUserUpdateFunction("warningCountdown")
  if not localPlayer.primaryFelony.settings.disableGenericFelonyPrompts then
    feedbackSystem.menusMaster.clearPrimaryTextPrompt()
    feedbackSystem.menusMaster.primaryTextPromptParam({
      prompt = "ID:243501",
      priority = 1,
      delayTime = 3
    })
  end
  OneShotSound.Play("HUD_Gen_Positive", false)
  if goalCallbacks.bustedGetaway then
    for i, callback in ipairs(goalCallbacks.bustedGetaway) do
      callback(getawayGameVehicle)
    end
  end
  unregisterAllGoalCallbacks()
  if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
    CopTimeTriggerCount = 0
    Commentary.TriggerEvent("CopBust", nil, nil, 0, false)
  end
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
  function endICamHUDRemoval()
    if not localPlayer:getTaskObject() then
      felony_feedback.endFelony()
    end
  end
  iCamCrashCam(getawayGameVehicle, endICamHUDRemoval, {prompts = true, willpowerRewards = true})
  if localPlayer:getTaskObject() then
    endScreenVehicle = takeOwnershipOfGetaway()
  else
    scoreSystem.willpowerReward(felony_feedback.felonyHUDTable.value, "copChase")
    progressionSystem.saveGame("took down the getaway in a freedrive felony")
    local reward = feedbackSystem.menusMaster.setWillpowerComma(felony_feedback.felonyHUDTable.value)
    feedbackSystem.menusMaster.secondaryTextPromptParam({
      prompt = "+" .. tostring(reward) .. tostring("%S"),
      icon1 = iconsTable.willpower,
      priority = 1,
      delayTime = 3
    })
  end
end
local workingVector = vec.vector()
function escaped(getawayGameVehicle)
  removeUserUpdateFunction("escapeCountdown")
  removeUserUpdateFunction("warningCountdown")
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  feedbackSystem.menusMaster.primaryTextPromptParam({
    prompt = "ID:243499",
    priority = 1,
    delayTime = 3
  })
  if goalCallbacks.getawayEscaped then
    for i, callback in ipairs(goalCallbacks.getawayEscaped) do
      callback(getawayGameVehicle)
    end
  end
  unregisterAllGoalCallbacks()
  if localPlayer:getTaskObject() then
    endScreenVehicle = takeOwnershipOfGetaway()
  else
    felony_feedback.endFelony(false)
  end
  if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
    CopTimeTriggerCount = 0
    Commentary.TriggerEvent("CopFree", nil, nil, 0, false)
  end
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
end
function allChasersWrecked(getawayGameVehicle, lastWreckedGameVehicle)
  removeUserUpdateFunction("escapeCountdown")
  removeUserUpdateFunction("warningCountdown")
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  feedbackSystem.menusMaster.primaryTextPromptParam({
    prompt = "ID:243499",
    priority = 1,
    delayTime = 3
  })
  if goalCallbacks.allChasersWrecked then
    for i, callback in ipairs(goalCallbacks.allChasersWrecked) do
      callback(getawayGameVehicle)
    end
  end
  unregisterAllGoalCallbacks()
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
  if localPlayer:getTaskObject() then
    endScreenVehicle = takeOwnershipOfLastChaserRemoved(lastWreckedGameVehicle)
  else
    felony_feedback.endFelony(false)
    iCamParams.cameraTargets = {lastWreckedGameVehicle}
    iCamActivationTableInput(iCamParams)
  end
end
function chaserAdded(getawayGameVehicle, chaseGameVehicle)
local copCharacters = {
    "1626880721", -- black cop male
	"900396692", -- black cop male 2
	"-197606133", -- white cop male
	"1397250177", -- hispanic cop male
	"549897793", -- female cop hispanic
	"-1748422665", -- female cop black
	"-1" -- empty
}
  print("A chasers has joined the chase getaway UID " .. tostring(getawayGameVehicle.uid) .. " chaser UID " .. tostring(chaseGameVehicle.uid))
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
      if chaseGameVehicle.model_id == 118 and not GameVehicleResource.withinRadius(chaseGameVehicle.position, player.position, 60) then
       GameVehicleResource.setCharacterSpoolingEntityIndex(chaseGameVehicle, 0, copCharacters[math.random(1, 6)])
	   GameVehicleResource.setCharacterSpoolingEntityIndex(chaseGameVehicle, 1, copCharacters[math.random(1, 7)])
      end	
  end  
end
function chaserRemoved(getawayGameVehicle, chaseGameVehicle)
  if localPlayer.currentVehicle and localPlayer.currentVehicle.gameVehicle == chaseGameVehicle then
    localPlayer.currentVehicle:setDebugRequiredVehicles(false)
  end
  vehicleManager.removeHighLODOccupants(chaseGameVehicle)
  if chaseGameVehicle.damage >= 1 then
    if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
	  wipeoutBlare = math.random(1,8)
	    if wipeoutBlare > 5 then 
	      OneShotSound.PlayOnGameVehicle(chaseGameVehicle, "Veh_Cop_Siren_Warning_Oneshot")
	    end
	end  
    if localPlayer.currentVehicle and localPlayer.currentVehicle.gameVehicle == chaseGameVehicle then
      CopTimeTriggerCount = 0
      Commentary.TriggerEvent("CopDstry", nil, nil, 0, true)
    end
    if goalCallbacks.chaserWrecked then
      for i, callback in ipairs(goalCallbacks.chaserWrecked) do
        callback(localPlayer:getChaserID(getawayGameVehicle, chaseGameVehicle))
      end
    end
  end
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
  localPlayer:removeChaser(getawayGameVehicle, chaseGameVehicle)
end
function escapingStarted(getawayGameVehicle, timer)
  local losingString = localPlayer.primaryFelony.settings.losingString or "ID:235433"
  local losingLastChaserTimer = timer
  local startTime = g_NetworkTime
  -- if localPlayer.primaryFelony.settings.getawayMode == "Cop" then 
    -- felony_patrollingVehicleManager.enablePatrollingVehiclesSpawning(true)
    -- PatrollingVehicleManager.SetRequiredVehicleCount(1)
    -- PatrollingVehicleManager.Enable(true)
  -- end  
  promptTable.prompt = losingString
  promptTable.value = losingLastChaserTimer
  promptTable.overrideTime = losingLastChaserTimer
  feedbackSystem.menusMaster.primaryTextPromptParam(promptTable)
  addUserUpdateFunction("escapeCountdown", function()
    local counter = math.ceil(losingLastChaserTimer - (g_NetworkTime - startTime))
    if not feedbackSystem.menusMaster.primaryPromptActive and not feedbackSystem.previewScreen.activityBeingPrompted and counter > 1 then
      feedbackSystem.menusMaster.primaryTextPromptParam(promptTable)
    end
    feedbackSystem.menusMaster.setPrimaryPromptCounterValues(losingString, counter)
    OneShotSound.PlayCountdown("HUD_Fel_54321")
    if counter == 10 and localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then	
      Commentary.TriggerEvent("CopLrng", nil, nil, 0, true)
    end
    CopTimeTriggerCount = 0
  end, 1 * updates.stepRate)
  localPlayer.primaryFelony.status.losingGetaway = true
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
  searching = true
  if not isMissionActive() then
    heatTable()
  end
end
function escapingStopped(getawayGameVehicle)
  removeUserUpdateFunction("escapeCountdown")
  if localPlayer:getTaskObject() then
    OneShotSound.Play("HUD_Gen_Positive")
  end
  felony_patrollingVehicleManager.enablePatrollingVehiclesSpawning(false)
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  if goalCallbacks.notLosingEvader then
    for i, callback in ipairs(goalCallbacks.notLosingEvader) do
      callback(getawayGameVehicle)
    end
  end
  localPlayer.primaryFelony.status.losingGetaway = false
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
  searching = false
  if not isMissionActive() then
    heatTable()
  end  
end
function leavingChaseAreaWarning(getawayGameVehicle)
  if not feedbackSystem.previewScreen.activityBeingPrompted then
    feedbackSystem.menusMaster.primaryTextPrompt("ID:245232")
  end
end
function leavingChaseAreaStarted(getawayGameVehicle, warningTime)
  removeUserUpdateFunction("escapeCountdown")
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  if not localPlayer:getTaskObject() then
    felony_feedback.pauseFelonyHUD()
  end
  local CurrentSteps = warningTime * (updates.stepRate / 15)
  local TimePerStep = warningTime / CurrentSteps
  local lastTime = warningTime + 1
  promptTable.prompt = "ID:245235"
  promptTable.value = warningTime
  promptTable.overrideTime = warningTime
  feedbackSystem.menusMaster.primaryTextPromptParam(promptTable)
  addUserUpdateFunction("warningCountdown", function()
    local counter = math.ceil(TimePerStep * CurrentSteps)
    CurrentSteps = CurrentSteps - 1
    if lastTime ~= counter then
      lastTime = counter
      if not feedbackSystem.menusMaster.primaryPromptActive and not feedbackSystem.previewScreen.activityBeingPrompted and counter > 1 then
        feedbackSystem.menusMaster.primaryTextPromptParam(promptTable)
      end
      feedbackSystem.menusMaster.setPrimaryPromptCounterValues("ID:245235", counter)
      OneShotSound.PlayCountdown("HUD_Fel_54321")
    end
  end, updates.stepRate / 8)
end
function leavingChaseAreaStopped(getawayGameVehicle)
  removeUserUpdateFunction("warningCountdown")
  feedbackSystem.menusMaster.clearPrimaryTextPrompt()
  if not localPlayer:getTaskObject() then
    felony_feedback.resumeFelonyHUD()
  end
end
function PAWindowStarted(getawayGameVehicle)
  if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
    CopTimeTriggerCount = 0
    Commentary.TriggerEvent("CopErng", nil, nil, 0, true)
  end
end
function triggerCopLostAudio(getawayGameVehicle)
  if localPlayer.currentVehicle and Chase.IsAChaser(localPlayer.currentVehicle.gameVehicle) then
    CopTimeTriggerCount = 0
    Commentary.TriggerEvent("CopLost", nil, nil, 0, true)
  end
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end
end
local getChaseChapterSettings = function()
  local highestChapterWithSettings = 0
  local requiredChapter = progressionSystem.getCurrentChapterInlcudingArtificial()
  for chapter, settings in next, chaseSettingsPerChapter, nil do
    if chapter <= requiredChapter and chapter > highestChapterWithSettings then
      highestChapterWithSettings = chapter
    end
  end
  return chaseSettingsPerChapter[highestChapterWithSettings]
end
function getSpecifiedMissionChaseSettings(missionName)
  local chaseSettings = {}
  duplicateTable(defaultChaseSettings, chaseSettings)
  local playerTaskObject = localPlayer:getTaskObject()
  local tempTable = getChaseChapterSettings(playerTaskObject)
  for key, value in next, tempTable, nil do
    if type(value) == "table" then
      if chaseSettings[key] then
        for k, v in next, value, nil do
          chaseSettings[key][k] = v
        end
      else
        chaseSettings[key] = value
      end
    else
      chaseSettings[key] = value
    end
  end
  if missionName then
    local missionFelonySettings = chaseSettingsPerMission[missionName]
    if missionFelonySettings then
      for k, v in next, missionFelonySettings, nil do
        chaseSettings[k] = v
      end
    end
  end
  return chaseSettings
end
function getChaseSettings()
  local chaseSettings = {}
  duplicateTable(defaultChaseSettings, chaseSettings)
  local playerTaskObject = localPlayer:getTaskObject()
  local tempTable = getChaseChapterSettings(playerTaskObject)
  for key, value in next, tempTable, nil do
    if type(value) == "table" then
      if chaseSettings[key] then
        for k, v in next, value, nil do
          chaseSettings[key][k] = v
        end
      else
        chaseSettings[key] = value
      end
    else
      chaseSettings[key] = value
    end
  end
  if playerTaskObject then
    local missionFelonySettings = chaseSettingsPerMission[playerTaskObject.coreData.instance.challenge.name]
    if missionFelonySettings then
      for k, v in next, missionFelonySettings, nil do
        chaseSettings[k] = v
      end
    end
    local routeName = playerTaskObject.coreData.instance.challenge.goalValues["Initial route"]
    if routeName then
      chaseSettings.getawayRoute = routes[routeName].roads
    end
  end
  if chaseSettings.playerAnalysis then
    PlayerAnalysis.AddWeight("Chase", chaseSettings.playerAnalysis)
    chaseSettings.playerAnalysis = nil
  end
  if chaseSettings.playerAnalysisDecay then
    PlayerAnalysis.SetDecay("Chase", chaseSettings.playerAnalysisDecay)
    chaseSettings.playerAnalysisDecay = nil
  end
  if localPlayer:getAbilityAvailable("zapReturn") then
    chaseSettings.rapidShiftAvaliable = true
  end
  return chaseSettings
end
function disownAgent(gameVehicle)
  local agent = vehicleManager.vehiclesByGameVehicle[gameVehicle]
  if agent then
    agent:setDebugRequiredVehicles(true)
    local taskObject = agent:getTaskObject()
    if taskObject then
      taskObject:delete()
    end
    if not agent.controlled then
      vehicleManager.unregisterVehicle(agent, false)
    end
  end
end
function startChase(evaderGameVehicle, chaseGameVehicle)
  local chaseSettings = getChaseSettings()
  localPlayer:createFelony(evaderGameVehicle, chaseSettings)
  disownAgent(evaderGameVehicle)
  local chaserAgent = vehicleManager.vehiclesByGameVehicle[chaseGameVehicle]
  local chaserControlled = chaserAgent and chaserAgent.controlled
  if chaseGameVehicle then
    disownAgent(chaseGameVehicle)
    localPlayer:addChaser(evaderGameVehicle, chaseGameVehicle)
  end
  Chase.Start(evaderGameVehicle, chaseGameVehicle, "Mission", chaseSettings)
  if not chaserControlled then
    Chase.OKToOwnVehicle(chaseGameVehicle)
  end
end
function addChaser(evaderGameVehicle, chaseGameVehicle)
  local chaserAgent = vehicleManager.vehiclesByGameVehicle[chaseGameVehicle]
  local chaserControlled = chaserAgent and chaserAgent.controlled
  disownAgent(chaseGameVehicle)
  localPlayer:addChaser(evaderGameVehicle, chaseGameVehicle)
  Chase.AddChaser(evaderGameVehicle, chaseGameVehicle)
  if not chaserControlled then
    Chase.OKToOwnVehicle(chaseGameVehicle)
  end
  if localPlayer.primaryFelony.settings.chaseMode == "Cop" then
    OneShotSound.Play("HUD_Fel_Gained")
  end 
end
function StartChaseFromTrafficEvent(evaderGameVehicle, chaseGameVehicle)
  disownAgent(evaderGameVehicle)
  local function callback()
    if not localPlayer.zapTransition then
      -- local chaserGameVehicle = localPlayer.currentVehicle.gameVehicle	
      -- felony_chase.startChase(evaderGameVehicle, chaserGameVehicle)	
      felony_suspiciousVehicleManager.startFelony(evaderGameVehicle, chaseGameVehicle) -- lul
      removeUserUpdateFunction("copwait")
    end
  end
  addUserUpdateFunction("copwait", callback, 1)
end
-- function StartChaseFromTrafficEvent(evaderGameVehicle, chaseGameVehicle)
  -- local chaseSettings = getChaseSettings()
  -- Chase.Start(evaderGameVehicle, chaseGameVehicle, "Mission", chaseSettings)
  -- localPlayer.primaryEvaderGameVehicle = evaderGameVehicle
-- end
function changeSettings(settings)
  Chase.SetSettings(localPlayer.primaryFelony.getawayGameVehicle, settings)
end
function takeOwnershipOfLastChaserRemoved(lastWreckedGameVehicle)
  if lastWreckedGameVehicle then
    local vehicle = vehicleManager.vehiclesByGameVehicle[lastWreckedGameVehicle] or vehicleManager.registerVehicle({gameVehicle = lastWreckedGameVehicle})
    vehicle:setDebugRequiredVehicles(true)
    return vehicle
  end
end
function takeOwnershipOfGetaway()
  if localPlayer.primaryFelony.getawayGameVehicle then
    local vehicle = vehicleManager.vehiclesByGameVehicle[localPlayer.primaryFelony.getawayGameVehicle] or vehicleManager.registerVehicle({
      gameVehicle = localPlayer.primaryFelony.getawayGameVehicle
    })
    vehicle:setDebugRequiredVehicles(true)
    return vehicle
  end
end
function takeOwnershipOfActivityGameVehicle()
  local activityGameVehicle = progressionSystem.getActivityGameVehicle()
  if activityGameVehicle then
    local vehicle = vehicleManager.vehiclesByGameVehicle[activityGameVehicle] or vehicleManager.registerVehicle({gameVehicle = activityGameVehicle})
    return vehicle
  end
end
Heat = {
  [1] = {
    requiredNumberOfChasers = 2,
    maximumNumberOfChasers = 8,
    normalRouteGenerationPreset = "Easiest", 
	catchupWindowRouteGenerationPreset = "Easiest",
	postHelperRouteGenerationPreset = "Easiest",
    getawayTraits = {
      desiredSpeed = 9999,
      drivingSkill = "Over-Cautious",
      reactionTime = "Slow"
    },
    groupTakedownParams = {
      groupTakeDownPerformanceBoost = 0
    },
    playerAnalysis = {
      Drift = 0,
      Jump = 0,
      Overtake = 0,
      OvertakeOncomming = 0,
      Trailer = 0,
      HighSpeedDriving = 0,
      SafeDriving = 0,
      PlayerCollision = 0,
      DrivingInAnAlley = 0
    },
    playerAnalysisDecay = 0
  },
  [2] = {
    requiredNumberOfChasers = 6,
    maximumNumberOfChasers = 8,
    normalRouteGenerationPreset = "Easy", 
	catchupWindowRouteGenerationPreset = "Easiest",
	postHelperRouteGenerationPreset = "Easy",
    getawayTraits = {
      desiredSpeed = 9999,
      drivingSkill = "Cautious",
      reactionTime = "Slow"
    },
    groupTakedownParams = {
      groupTakeDownPerformanceBoost = 0
    },	
    playerAnalysis = {
      Drift = 0,
      Jump = 0,
      Overtake = 0,
      OvertakeOncomming = 0,
      Trailer = 0,
      HighSpeedDriving = 0,
      SafeDriving = 0,
      PlayerCollision = 0,
      DrivingInAnAlley = 0
    },
    playerAnalysisDecay = 0
  },
  [3] = {
    requiredNumberOfChasers = 6,
    maximumNumberOfChasers = 8,
    normalRouteGenerationPreset = "Medium", 
	catchupWindowRouteGenerationPreset = "Easiest",
	postHelperRouteGenerationPreset = "Medium",
    getawayTraits = {
      desiredSpeed = 9999,
      drivingSkill = "Average",
      reactionTime = "Average"
    },
    groupTakedownParams = {
      groupTakeDownPerformanceBoost = 0
    },	
    playerAnalysis = {
      Drift = 0,
      Jump = 0,
      Overtake = 0,
      OvertakeOncomming = 0,
      Trailer = 0,
      HighSpeedDriving = 0,
      SafeDriving = 0,
      PlayerCollision = 0,
      DrivingInAnAlley = 0
    },
    playerAnalysisDecay = 0
  },
  [4] = {
    requiredNumberOfChasers = 6,
    maximumNumberOfChasers = 8,
    normalRouteGenerationPreset = "Hard", 
	catchupWindowRouteGenerationPreset = "Easiest",
	postHelperRouteGenerationPreset = "Hard",
    getawayTraits = {
      desiredSpeed = 9999,
      drivingSkill = "Professional",
      reactionTime = "Fast"
    },
    groupTakedownParams = {
      groupTakeDownPerformanceBoost = 0
    },	
    playerAnalysis = {
      Drift = 0,
      Jump = 0,
      Overtake = 0,
      OvertakeOncomming = 0,
      Trailer = 0,
      HighSpeedDriving = 0,
      SafeDriving = 0,
      PlayerCollision = 0,
      DrivingInAnAlley = 0
    },
    playerAnalysisDecay = 0
  },  
  [5] = {
    requiredNumberOfChasers = 6,
    maximumNumberOfChasers = 8,
    getawayTraits = {
	  normalRouteGenerationPreset = "Easy",
	  catchupWindowRouteGenerationPreset = "Easiest",
      desiredSpeed = 25
    },
    groupTakedownParams = {
      groupTakeDownPerformanceBoost = 0
    },	
    playerAnalysis = {
      Drift = 0,
      Jump = 0,
      Overtake = 0,
      OvertakeOncomming = 0,
      Trailer = 0,
      HighSpeedDriving = 0,
      SafeDriving = 0,
      PlayerCollision = 0,
      DrivingInAnAlley = 0
    },
    playerAnalysisDecay = 0
  }  
}
