
----------- INSTALLATION ------------

   Simply put the contents of the zip file into the root directory of Driver: San Francisco
 

----------- OPENING MENU ------------

   Keyboard:      X + (Arrow)UP (yes the key X, not a typo!)
   Xbox:          X + (Dpad)UP
   Playstation:   Square + (Dpad)UP


----------- MENU CONTROLS ------------

   You can scroll all the way down with the dpad to a submenu called "Hotkey/Settings"
   This menu explains all the buttons on how to use the menu 

   Navigation : 
     Keyboard:    Arrow keys
     Controller:  DPAD

   Enter/Accept : 
     Keyboard:    Enter
     Xbox:        A
     Playstation: X

   Back/Close : 
     Keyboard:    Backspace
     Xbox:        B
     Playstation: Circle

   Hide Menu :
     Keyboard:    Z
     Xbox:        Y
     Playstation: Triangle

     This will hide the menu and remembers where you were when you open it up again


----------- DISCORD ------------

   For any questions you can find me and the rest of the drivers in the following discord:
   https://discord.gg/sxt45rR


----------- CREDITS------------

   Snoopii     - Creator of this ModMenu; 
                 A lot of work went into the menu system, maybe I will make a video about it one day

   FireBoyd78  - Creator of the initial ModMenu; 
                 Thanks to him this was all possible!

   Soapy       - His DNG hook which doesn't require us to hook through scriptsluascripts.fchunk
                 It also features other cool stuff this modmenu makes use off!

   Olanov      - He supplied code for some options in the menu. 
                 Knows a heck alot about the game and came with some great ideas!

   McNally     - The main source of suggestions. Some features were created for purpose of creating. 
                 Thanks to him testing and reporting bugs!

   KekAnTing   - For supplying some features that ended up in the menu!

   And anyone I forgot to mention. You all matter :)

